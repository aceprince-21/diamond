var app = app || {}

app.content = {
    accordion:function(e,f){
        $(e).find(f).click(function(){
            if($(this).hasClass('active') === true){
                $(this).parent().removeClass('active');
                $(this).removeClass('active')
                return false;
            }else{
                $(this).parent().addClass('active');
                $(this).addClass('active')
                return false;
            }
        });
    },
    mobileCopyright:function(e,f){
        var checkWidth = $(window).width();
        var _obj = $(e);
        if(checkWidth < 767){
            _obj.addClass('accordion');
			app.content.accordion(e,f);
        }
        else{
            _obj.removeClass('accordion');
			app.content.accordion(e,f);
        }
        
    },
	mobileMenu:function(e,f){
		$(e).click(function(){
			if($(f).hasClass('active')){
			  $(f).removeClass('active');
			  $(this).removeClass('active');
		    }
			else{
			   $(f).addClass('active');
			  $(this).addClass('active');
			}
		});
		
	},
	closebtn:function(e){
		$(e).click(function(){
			 if($(this).parent().parent().hasClass('active')){
				 $(this).parent().parent().removeClass('active');
			 }
		});
	},
	tabs:function(){
		$('.taby').each(function(){
			 var obj = $(this);
			 obj.find('.nav a').click(function(){
				 obj.find('.nav a').removeClass('active');
				 $(this).addClass('active');
				  var get_attr = $(this).attr('data-href');
				  var sub_string = get_attr.split('#')[1];
				  var get_child = obj.find('.tab-wrapper li').length;
				  console.log(get_child);
				  for(i=0; i< get_child; i++){
					  var newobj = obj.find('.tab-wrapper li').eq(i).attr('id');
					  if(obj.find('.tab-wrapper li').eq(i).attr('id') == sub_string){
						  obj.find('.tab-wrapper li').removeClass('active');
						  obj.find('.tab-wrapper li').eq(i).addClass('active');
						 
					  }
				  }
				   app.content.slider('.left');
			 });
		});
	},
	slider:function(e){
				$(e).slick({
			  dots: false,
			  infinite: true,
			  speed: 300,
			  slidesToShow: 4,
			  slidesToScroll: 4,
			  adaptiveHeight: true,
			  lazyLoad: 'ondemand',
			  responsive: [
				{
				  breakpoint: 1024,
				  settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true
				  }
				},
				{
				  breakpoint: 600,
				  settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				  }
				},
				{
				  breakpoint: 480,
				  settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				  }
				}
				// You can unslick at a given breakpoint now by adding:
				// settings: "unslick"
				// instead of a settings object
			  ]
			});	
	}
         
}


$(document).ready(function(){
    app.content.accordion('.accordion', 'a');
    app.content.mobileCopyright('.footer-list', 'span');
    app.content.mobileCopyright('.mobile-tab li', 'span.col-lg-12');
	app.content.mobileMenu('.mobile-menu', '.nav-menu');
	app.content.mobileMenu('.filter-mobile-button', '.subnav');
	app.content.closebtn('.close-menu');
	app.content.tabs();
	app.content.slider('.left');
	app.content.slider('.center');
	

});

$(window).resize(function(){
        app.content.mobileCopyright('.footer-list','span');
		app.content.mobileCopyright('.mobile-tab li', '.wrapper');
});


